test_that("multipart uploads use files and form fields", {
  path <- withr::local_tempfile(fileext = ".bin")
  writeBin(charToRaw("image bytes"), path)
  client <- phenoworks_client("key")
  httr2::local_mocked_responses(function(req) {
    expect_identical(req$method, "POST")
    expect_identical(req$url, "http://localhost:9000/api/assets")
    expect_identical(req$body$type, "multipart")
    # httr2 deliberately obfuscates multipart fields; the loopback test checks wire bytes.
    json_response('{"id":3}', 201L)
  })
  expect_identical(client$assets$upload(path, plot_id = 9)$id, 3L)
})

test_that("tus resumes from server offset and finalizes without leaking API credentials", {
  path <- withr::local_tempfile()
  writeBin(charToRaw("abcdef"), path)
  client <- phenoworks_client("api-secret")
  offset <- 2
  chunks <- list()
  session <- NULL
  httr2::local_mocked_responses(function(req) {
    if (endsWith(req$url, "/uploads/complete")) {
      expect_identical(request_headers(req)[["X-API-Key"]], "api-secret")
      expect_identical(req$body$data$scope, "study-file")
      expect_identical(req$body$data$study_id, 8)
      expect_identical(req$body$data$file_id, 3L)
      return(json_response('{"file":{"id":3}}'))
    }
    expect_null(request_headers(req)[["X-API-Key"]])
    expect_null(request_headers(req)[["Authorization"]])
    expect_identical(request_headers(req)[["Tus-Resumable"]], "1.0.0")
    expect_identical(req$url, "https://storage.example/uploads/session")
    if (req$method == "HEAD") return(httr2::response(headers = list(`Upload-Offset` = "2")))
    expect_identical(req$method, "PATCH")
    expect_equal(as.numeric(request_headers(req)[["Upload-Offset"]]), offset)
    expect_identical(request_headers(req)[["Content-Type"]], "application/offset+octet-stream")
    chunks[[length(chunks) + 1L]] <<- req$body$data
    offset <<- offset + length(req$body$data)
    httr2::response(status_code = 204L, headers = list(`Upload-Offset` = as.character(offset)))
  })
  result <- client$transfer_upload(upload_registration(6, study_id = 8), path,
                                   upload_url = "session", chunk_size = 2,
                                   session_created = function(url) session <<- url)
  expect_identical(result$file$id, 3L)
  expect_identical(session, "https://storage.example/uploads/session")
  expect_identical(rawToChar(do.call(c, chunks)), "cdef")
})

test_that("new tus sessions carry upload metadata and use returned locations", {
  path <- withr::local_tempfile(fileext = ".csv")
  writeBin(charToRaw("abc"), path)
  client <- phenoworks_client("key", "https://example.com/proxy")
  methods <- character()
  httr2::local_mocked_responses(function(req) {
    methods <<- c(methods, req$method)
    if (endsWith(req$url, "/uploads/project-files")) {
      expect_identical(req$body$data$project_id, 7)
      expect_equal(req$body$data$size_bytes, 3)
      expect_identical(req$body$data$filename, basename(path))
      return(json_response(paste0('{"file":{"id":3,"project_id":7,"metadata_json":{"size_bytes":3,"upload_permit":"permit"}},',
                                  '"upload":{"backend":"tusd","upload_url":"/files/"}}')))
    }
    if (endsWith(req$url, "/uploads/complete")) return(json_response('{"ok":true}'))
    expect_null(request_headers(req)[["X-API-Key"]])
    if (req$method == "POST") {
      expect_identical(req$url, "https://example.com/files/")
      expect_identical(request_headers(req)[["Upload-Length"]], "3")
      expect_match(request_headers(req)[["Upload-Metadata"]], "uploadPermit cGVybWl0", fixed = TRUE)
      return(httr2::response(status_code = 201L, headers = list(Location = "/files/session")))
    }
    expect_identical(req$url, "https://example.com/files/session")
    httr2::response(status_code = 204L, headers = list(`Upload-Offset` = if (req$method == "HEAD") "0" else "3"))
  })
  expect_true(client$upload_project_file(7, path)$ok)
  expect_identical(methods, c("POST", "POST", "HEAD", "PATCH", "POST"))
})

test_that("GCS resumes with ranges and requires final completion", {
  path <- withr::local_tempfile()
  writeBin(as.raw(rep(65L, 262145L)), path)
  client <- phenoworks_client("key")
  put_count <- 0L
  httr2::local_mocked_responses(function(req) {
    if (req$method == "POST") return(json_response('{"ok":true}'))
    expect_null(request_headers(req)[["X-API-Key"]])
    expect_identical(req$method, "PUT")
    put_count <<- put_count + 1L
    if (put_count == 1L) {
      expect_identical(request_headers(req)[["Content-Range"]], "bytes */262145")
      return(httr2::response(status_code = 308L))
    }
    if (put_count == 2L) {
      expect_identical(request_headers(req)[["Content-Range"]], "bytes 0-262143/262145")
      expect_length(req$body$data, 262144L)
      return(httr2::response(status_code = 308L, headers = list(Range = "bytes=0-262143")))
    }
    expect_identical(request_headers(req)[["Content-Range"]], "bytes 262144-262144/262145")
    expect_length(req$body$data, 1L)
    httr2::response(status_code = 200L)
  })
  expect_true(client$transfer_upload(upload_registration(262145, "gcs"), path,
                                     chunk_size = 262144)$ok)
  expect_identical(put_count, 3L)
})

test_that("invalid registration and transfer acknowledgements never finalize", {
  path <- withr::local_tempfile()
  writeBin(charToRaw("abc"), path)
  client <- phenoworks_client("key")
  expect_error(client$transfer_upload(upload_registration(9), path), "File size")
  expect_error(client$transfer_upload(upload_registration(3, "gcs"), path, chunk_size = 3), "multiple")
  httr2::local_mocked_responses(function(req) {
    expect_false(endsWith(req$url, "/uploads/complete"))
    if (req$method == "HEAD") return(httr2::response(headers = list(`Upload-Offset` = "0")))
    httr2::response(status_code = 204L, headers = list(`Upload-Offset` = "2"))
  })
  expect_error(client$transfer_upload(upload_registration(3), path, upload_url = "session"), "offset mismatch")
  httr2::local_mocked_responses(function(req) {
    expect_false(endsWith(req$url, "/uploads/complete"))
    httr2::response(status_code = 308L)
  })
  expect_error(client$transfer_upload(upload_registration(3, "gcs"), path), "did not finalize")
})

test_that("empty and already-complete uploads can finalize safely", {
  path <- withr::local_tempfile()
  file.create(path)
  client <- phenoworks_client("key")
  httr2::local_mocked_responses(function(req) {
    if (req$method == "POST") return(json_response('{"ok":true}'))
    expect_identical(request_headers(req)[["Content-Range"]], "bytes */0")
    httr2::response(status_code = 200L)
  })
  expect_true(client$transfer_upload(upload_registration(0, "gcs"), path)$ok)
})
