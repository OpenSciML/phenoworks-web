test_that("configuration normalizes roots and keeps credentials out of print", {
  for (url in c("https://example.com/prefix", "https://example.com/prefix/api/")) {
    client <- phenoworks_client("secret-key", url)
    expect_identical(client$base_url, "https://example.com/prefix/api/")
    expect_false(any(grepl("secret-key", capture.output(print(client)))))
  }
  withr::local_envvar(c(PHENOWORKS_API_KEY = "env-key",
                      PHENOWORKS_API_URL = "http://localhost:9000"))
  expect_identical(phenoworks_client()$api_key, "env-key")
  expect_identical(phenoworks_client()$base_url, "http://localhost:9000/api/")
  expect_identical(phenoworks_client("explicit")$api_key, "explicit")
})

test_that("invalid configuration fails before requesting", {
  for (key in list("", NA_character_, c("a", "b"), "a\nb")) {
    expect_error(phenoworks_client(key), "api_key")
  }
  for (url in c("ftp://example.com", "https://user:pass@example.com",
                "https://example.com?q=1", "https://example.com/#part")) {
    expect_error(phenoworks_client("key", url), "base_url")
  }
  for (timeout in list(0, -1, Inf, NA_real_, "30", c(1, 2))) {
    expect_error(phenoworks_client("key", timeout = timeout), "timeout")
  }
})

test_that("requests use the expected authentication, URL, and JSON shape", {
  client <- phenoworks_client("secret-key", "https://example.com/prefix")
  httr2::local_mocked_responses(function(req) {
    expect_identical(req$url, "https://example.com/prefix/api/datasets?project_id=7")
    expect_identical(request_headers(req)[["X-API-Key"]], "secret-key")
    expect_identical(req$options$followlocation, FALSE)
    httr2::response(headers = list(`Content-Type` = "application/json"),
                    body = charToRaw('[{"id":42,"name":"Example"}]'))
  })
  result <- phenoworks_request(client, "/api/datasets",
                               query = list(project_id = 7, study_id = NULL))
  expect_identical(result[[1]]$id, 42L)
  expect_type(result, "list")
})

test_that("writes preserve methods and bodies and empty responses return NULL", {
  client <- phenoworks_client("key")
  httr2::local_mocked_responses(function(req) {
    expect_identical(req$method, "PATCH")
    expect_identical(req$body$data, list(name = "updated"))
    httr2::response(status_code = 204L)
  })
  expect_null(phenoworks_request(client, "projects/1", method = "PATCH",
                                 body = list(name = "updated")))
})

test_that("HTTP errors include status and redact secrets without retrying", {
  client <- phenoworks_client("secret-key")
  for (status in c(302L, 401L, 403L, 404L, 422L, 500L)) {
    calls <- 0L
    httr2::local_mocked_responses(function(req) {
      calls <<- calls + 1L
      httr2::response(status_code = status,
                      body = charToRaw('Rejected secret-key'))
    })
    error <- tryCatch(phenoworks_projects(client), error = identity)
    expect_s3_class(error, "phenoworks_api_error")
    expect_identical(error$status_code, status)
    expect_identical(error$detail, "Rejected [REDACTED]")
    expect_identical(calls, 1L)
  }
})

test_that("paths cannot redirect credentials outside the API root", {
  client <- phenoworks_client("key")
  for (path in c("https://other.com", "//other.com", "../auth", "/api/../auth",
                 "%2e%2e/auth", "projects?x=1", "projects#x", "foo\\bar",
                 "%2f%2fother.com")) {
    expect_error(phenoworks_request(client, path), "API-relative")
  }
  expect_error(phenoworks_request(client, "projects", query = list(1)), "named list")
})

test_that("read helpers target matching SDK routes", {
  client <- phenoworks_client("key")
  routes <- c("auth/me", "projects", "datasets", "pipelines")
  helpers <- list(phenoworks_me, phenoworks_projects, phenoworks_datasets,
                  phenoworks_pipelines)
  for (i in seq_along(routes)) {
    httr2::local_mocked_responses(function(req) {
      expect_identical(req$url, paste0(client$base_url, routes[[i]]))
      httr2::response(status_code = 204L)
    })
    expect_null(helpers[[i]](client))
  }
})
