test_that("credentials are replaced per request, not merged or mutated", {
  withr::local_envvar(c(PHENOWORKS_API_KEY = "environment-key"))
  client <- phenoworks_client(auth_token = "fixed-token")
  observed <- list()
  httr2::local_mocked_responses(function(req) {
    observed[[length(observed) + 1L]] <<- request_headers(req)
    json_response('{}')
  })
  client$projects$list(headers = list(`x-api-key` = "other-key"))
  client$projects$list()
  expect_identical(observed[[1]][["X-API-Key"]], "other-key")
  expect_null(observed[[1]][["Authorization"]])
  expect_identical(observed[[2]][["Authorization"]], "Bearer fixed-token")
  expect_null(observed[[2]][["X-API-Key"]])
  forwarded <- phenoworks_client(forward_auth_headers = TRUE)
  expect_error(forwarded$projects$list(), "requires credentials")
  forwarded$projects$list(headers = list(Authorization = "bearer incoming"))
  expect_identical(observed[[3]][["Authorization"]], "Bearer incoming")
  expect_error(phenoworks_client("key", auth_token = "token"), "only one")
  expect_error(client$get("projects", headers = list(Authorization = "Basic bad")), "bearer")
  expect_error(client$get("projects", headers = list(`X-API-Key` = "key", Authorization = "Bearer token")), "exactly one")
})

test_that("typed HTTP failures redact the active credential", {
  client <- phenoworks_client(auth_token = "bearer-secret")
  for (status in c(401L, 403L, 404L)) {
    httr2::local_mocked_responses(function(req) {
      httr2::response(status_code = status, body = charToRaw("bearer-secret rejected"))
    })
    error <- tryCatch(client$get("projects"), error = identity)
    expected <- switch(as.character(status), `401` = "phenoworks_authentication_error",
                       `403` = "phenoworks_permission_denied_error", `404` = "phenoworks_not_found_error")
    expect_s3_class(error, expected)
    expect_false(grepl("bearer-secret", conditionMessage(error), fixed = TRUE))
  }
})

test_that("resource methods preserve verbs, payloads, filters and encoded identifiers", {
  client <- phenoworks_client("key", "https://example.com/prefix")
  requests <- list()
  httr2::local_mocked_responses(function(req) {
    requests[[length(requests) + 1L]] <<- req
    json_response('{"id":7}')
  })
  client$datasets$list(study_id = 4, project_id = NULL)
  client$projects$create(list(name = "Trial"))
  client$annotation_groups$update("group-a", list(name = "Plots"))
  client$resource_policies$update(2, list(name = "Research"))
  client$analysis_blocks$install_for_account("a/b ?#", list(version = "1"))
  expect_identical(requests[[1]]$url, "https://example.com/prefix/api/datasets?study_id=4")
  expect_identical(requests[[2]]$body$data, list(name = "Trial"))
  expect_identical(requests[[3]]$method, "PATCH")
  expect_identical(requests[[4]]$method, "PUT")
  expect_match(requests[[5]]$url, "a%2Fb%20%3F%23/installation", fixed = TRUE)
})

test_that("modality discovery checks declared support and preserves order", {
  client <- phenoworks_client("key")
  httr2::local_mocked_responses(function(req) {
    expect_match(req$url, "project_id=7", fixed = TRUE)
    json_response('[{"id":1,"supported_modalities":["THERMAL"]},{"id":2},{"id":3,"supported_modalities":["rgb","thermal"]}]')
  })
  result <- client$datasets$filter_by_modality(" Thermal ", project_id = 7)
  expect_identical(vapply(result, `[[`, integer(1), "id"), c(1L, 3L))
})

test_that("query vectors use repeated keys like the Python SDK", {
  client <- phenoworks_client("key")
  httr2::local_mocked_responses(function(req) {
    expect_match(req$url, "modality=rgb&modality=thermal", fixed = TRUE)
    json_response('[]')
  })
  client$get("datasets", params = list(modality = c("rgb", "thermal")))
})
