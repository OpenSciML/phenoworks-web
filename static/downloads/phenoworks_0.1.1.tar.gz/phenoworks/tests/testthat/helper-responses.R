# Read custom headers from an httr2_request as a named list of strings.
# Reveals only synthetic test credentials so authentication assertions remain
# effective with httr2's protected header storage. Older supported httr2
# versions predate the public accessor and store plain header values.
request_headers <- function(req) {
  if ("req_get_headers" %in% getNamespaceExports("httr2")) {
    return(httr2::req_get_headers(req, redacted = "reveal"))
  }
  req$headers
}

# Build a JSON transport fixture with the same decoding behavior as the API.
json_response <- function(body, status = 200L) {
  httr2::response(status_code = status, headers = list(`Content-Type` = "application/json"),
                  body = charToRaw(body))
}

# Open a bounded in-memory stream for download tests without a listening server.
stream_response <- function(body, status = 200L, headers = list()) {
  response <- httr2::response(status_code = status, headers = headers)
  response$body <- rawConnection(charToRaw(body))
  response
}

# A registration fixture supporting both project and study resumable uploads.
upload_registration <- function(size, backend = "tusd", study_id = NULL) {
  list(file = list(id = 3L, project_id = 7L, study_id = study_id,
                   metadata_json = list(size_bytes = size, upload_permit = "permit")),
       upload = list(backend = backend, upload_url = "https://storage.example/uploads/",
                      headers = list()))
}
