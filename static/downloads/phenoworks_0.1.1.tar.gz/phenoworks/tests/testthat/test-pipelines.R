test_that("pipeline submission, polling, artifacts and reconnect retain both IDs", {
  client <- phenoworks_client("key")
  submissions <- 0L
  polls <- 0L
  httr2::local_mocked_responses(function(req) {
    if (req$method == "POST") {
      submissions <<- submissions + 1L
      expect_identical(req$body$data$dataset_id, 42)
      expect_identical(req$body$data$modalities, list("thermal"))
      return(json_response('{"id":90,"payload":{"pipeline_id":12}}', 202L))
    }
    if (endsWith(req$url, "/pipelines/12")) {
      polls <<- polls + 1L
      return(json_response(if (polls == 1L) '{"status":"running"}' else '{"status":"completed"}'))
    }
    if (endsWith(req$url, "/operations/90")) return(json_response('{"status":"running"}'))
    expect_match(req$url, "artifacts?pipeline_id=12", fixed = TRUE)
    json_response('[{"id":51,"format":"csv","status":"ready"}]')
  })
  run <- client$run_pipeline(42, list(list(block = "test")), modalities = "thermal")
  expect_identical(run$pipeline_id, 12L)
  expect_identical(run$operation_id, 90L)
  expect_identical(run$wait(poll_interval = 0.001)$status, "completed")
  expect_identical(run$artifacts()[[1]]$id, 51L)
  expect_identical(client$pipeline_run(12)$status()$status, "completed")
  expect_identical(submissions, 1L)
})

test_that("pipeline and operation failures terminate waiting", {
  client <- phenoworks_client("key")
  for (status in c("failed", "cancelled")) {
    for (operation_failure in c(TRUE, FALSE)) {
      httr2::local_mocked_responses(function(req) {
        value <- if (operation_failure && grepl("/pipelines/", req$url)) "pending" else status
        json_response(paste0('{"status":"', value, '","error_message":"worker failed"}'))
      })
      error <- tryCatch(client$pipeline_run(12, 90)$wait(), error = identity)
      expect_s3_class(error, "phenoworks_pipeline_failed_error")
      expect_identical(error$pipeline_id, 12)
      expect_identical(error$record$status, status)
    }
  }
})

test_that("timeout does not cancel and explicit cancel uses the correct route", {
  client <- phenoworks_client("key")
  calls <- list()
  httr2::local_mocked_responses(function(req) {
    calls[[length(calls) + 1L]] <<- req
    json_response('{"status":"running"}')
  })
  error <- tryCatch(client$pipeline_run(12)$wait(timeout = 0), error = identity)
  expect_s3_class(error, "phenoworks_pipeline_timeout_error")
  expect_length(calls, 1L)
  expect_identical(calls[[1]]$method, "GET")
  client$pipeline_run(12)$cancel()
  expect_identical(calls[[2]]$method, "POST")
  expect_match(calls[[2]]$url, "/pipelines/12/cancel", fixed = TRUE)
})
