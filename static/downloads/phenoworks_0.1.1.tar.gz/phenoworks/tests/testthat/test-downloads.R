test_that("artifact downloads produce readable CSV and preserve existing files", {
  client <- phenoworks_client("key")
  directory <- withr::local_tempdir()
  destination <- file.path(directory, "nested", "result.csv")
  testthat::local_mocked_bindings(req_perform_connection = function(req) {
    expect_identical(req$url, "http://localhost:9000/api/artifacts/51/content")
    expect_identical(request_headers(req)[["X-API-Key"]], "key")
    expect_false(req$options$followlocation)
    stream_response("plot,trait\n1,2\n", headers = list(`Content-Length` = "15"))
  }, .package = "httr2")
  # Content length is measured in bytes, not CSV rows.
  expect_equal(nchar("plot,trait\n1,2\n", type = "bytes"), 15)
  path <- client$artifacts$download(51, destination)
  expect_identical(read.csv(path)$trait, 2L)
  expect_error(client$artifacts$download(51, destination), "already exists")
  expect_identical(client$download_artifact(51, destination, overwrite = TRUE), destination)
})

test_that("incomplete and failed downloads never replace a destination", {
  client <- phenoworks_client("key")
  directory <- withr::local_tempdir()
  destination <- file.path(directory, "result.csv")
  writeLines("existing", destination)
  testthat::local_mocked_bindings(req_perform_connection = function(req) {
    stream_response("partial", headers = list(`Content-Length` = "100"))
  }, .package = "httr2")
  expect_error(client$artifacts$download(1, destination, overwrite = TRUE), "Incomplete download")
  expect_identical(readLines(destination), "existing")
  expect_identical(list.files(directory, all.files = TRUE, no.. = TRUE), "result.csv")
  testthat::local_mocked_bindings(req_perform_connection = function(req) {
    stream_response("key rejected", 403L)
  }, .package = "httr2")
  expect_error(client$artifacts$download(1, destination, overwrite = TRUE), class = "phenoworks_permission_denied_error")
  expect_identical(readLines(destination), "existing")
})

test_that("saved streams report digests and progress and clean up callback failures", {
  directory <- withr::local_tempdir()
  destination <- file.path(directory, "output")
  response <- stream_response("abc", headers = list(`Content-Length` = "3"))
  on.exit(close(response$body))
  counts <- numeric()
  result <- phenoworks_save_stream(response, destination, progress = function(done, total) {
    counts <<- c(counts, done)
    expect_equal(total, 3)
  })
  expect_identical(result$sha256, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
  expect_equal(result$size_bytes, 3)
  expect_equal(counts, c(0, 3))
  broken <- stream_response("abc")
  on.exit(close(broken$body), add = TRUE)
  expect_error(phenoworks_save_stream(broken, destination, overwrite = TRUE,
                                     progress = function(done, total) stop("callback failed")), "callback failed")
  expect_identical(list.files(directory, all.files = TRUE, no.. = TRUE), "output")
})
