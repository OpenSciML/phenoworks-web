library(testthat)
library(phenoworks)

test_check("phenoworks")
