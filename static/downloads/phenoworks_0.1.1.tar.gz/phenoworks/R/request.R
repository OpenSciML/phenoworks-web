#' Call a PhenoWorks JSON API endpoint
#'
#' Uses the client's API key. Redirects are rejected and requests are not
#' automatically retried, so writes are not accidentally submitted twice.
#'
#' @param client A client created by [phenoworks_client()].
#' @param path API-relative endpoint, such as "projects" or "/api/datasets".
#'   Absolute URLs, traversal segments, query strings and fragments are rejected.
#' @param method HTTP method: GET, POST, PUT, PATCH, DELETE, HEAD, or OPTIONS.
#' @param query Named list of query parameters. NULL entries are omitted;
#'   vector values produce repeated query parameters.
#' @param body JSON-compatible R value, typically a named list. NULL sends no
#'   body. Scalars are unboxed; use a list for a JSON array with one element.
#' @param headers Optional replacement credentials: named list with X-API-Key
#'   or Authorization (Bearer token). Unrelated headers are ignored.
#' @return Decoded JSON as ordinary R lists and scalars, or NULL for an empty
#'   response. Non-2xx responses raise a phenoworks_api_error with a numeric
#'   status_code and redacted detail. Network errors come from httr2.
#' @export
phenoworks_request <- function(client, path, method = "GET", query = list(),
                              body = NULL, headers = NULL) {
  req <- api_request(client, path, method, query, body, headers)
  decode_response(httr2::req_perform(req), credential_secrets(request_auth(client, headers)))
}

#' Build an authenticated HTTP request
#' @inheritParams phenoworks_request
#' @return An httr2 request with no retries or redirects.
#' @keywords internal
api_request <- function(client, path, method = "GET", query = list(), body = NULL,
                        headers = NULL) {
  auth <- request_auth(client, headers)
  check_string(path, "path")
  decoded <- utils::URLdecode(path)
  if (grepl("^[a-zA-Z][a-zA-Z0-9+.-]*:|^//|[?#]", path) ||
      startsWith(decoded, "//") || grepl("\\", decoded, fixed = TRUE) ||
      any(strsplit(decoded, "/", fixed = TRUE)[[1]] %in% c(".", ".."))) {
    stop("Use an API-relative path and pass query parameters through query.",
         call. = FALSE)
  }
  path <- sub("^/?api/", "", path)
  path <- sub("^/+", "", path)
  check_string(method, "method")
  method <- match.arg(toupper(method),
                      c("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"))
  if (!is.list(query) || (length(query) > 0L &&
      (is.null(names(query)) || anyNA(names(query)) || any(!nzchar(names(query)))))) {
    stop("query must be a named list.", call. = FALSE)
  }
  query <- query[!vapply(query, is.null, logical(1))]
  req <- httr2::request(paste0(client$base_url, path)) |>
    httr2::req_headers(Accept = "application/json") |>
    httr2::req_user_agent("phenoworks-r/0.1.0") |>
    httr2::req_timeout(client$timeout) |>
    httr2::req_options(followlocation = FALSE) |>
    httr2::req_error(is_error = function(resp) FALSE)
  req <- do.call(httr2::req_headers_redacted, c(list(req), auth))
  if (length(query)) req <- do.call(httr2::req_url_query, c(list(req, .multi = "explode"), query))
  if (!is.null(body)) req <- httr2::req_body_json(req, body, auto_unbox = TRUE)
  httr2::req_method(req, method)
}

#' Raise a structured error for unsuccessful HTTP responses
#' @param resp An httr2 response.
#' @param secrets Character vector of secrets to redact.
#' @return Response invisibly on success; a typed condition on failure.
#' @keywords internal
check_response <- function(resp, secrets = character()) {
  status <- httr2::resp_status(resp)
  if (status < 200L || status >= 300L) {
    detail <- if (httr2::resp_has_body(resp)) httr2::resp_body_string(resp) else ""
    for (secret in secrets[nzchar(secrets)]) {
      detail <- gsub(secret, "[REDACTED]", detail, fixed = TRUE)
    }
    detail <- substr(detail, 1L, 4000L)
    specific <- switch(as.character(status),
                       `401` = "phenoworks_authentication_error",
                       `403` = "phenoworks_permission_denied_error",
                       `404` = "phenoworks_not_found_error", NULL)
    stop(structure(list(message = paste0("PhenoWorks API returned HTTP ",
                                        status, ": ", detail),
                        call = NULL, status_code = status, detail = detail),
                   class = c(specific, "phenoworks_api_error", "phenoworks_error",
                             "error", "condition")))
  }
  invisible(resp)
}

#' Decode a successful JSON response
#' @param resp An httr2 response.
#' @param secrets Character vector of credentials to redact from errors.
#' @return Decoded JSON or NULL; HTTP failures raise typed errors.
#' @keywords internal
decode_response <- function(resp, secrets = character()) {
  check_response(resp, secrets)
  if (!httr2::resp_has_body(resp)) return(NULL)
  httr2::resp_body_json(resp, simplifyVector = FALSE)
}

#' Encode one route identifier
#' @param value Single non-empty character or numeric path component.
#' @return Percent-encoded string; traversal segments raise an error.
#' @keywords internal
path_component <- function(value) {
  value <- as.character(value)
  check_string(value, "identifier")
  if (value %in% c(".", "..")) stop("Invalid path identifier.")
  utils::URLencode(value, reserved = TRUE, repeated = TRUE)
}
