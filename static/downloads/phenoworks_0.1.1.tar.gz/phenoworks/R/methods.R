#' Bind convenience methods to a client
#' @param client Configured client without bound methods.
#' @return Named list of functions forwarding to the documented standalone API.
#' @keywords internal
bind_client_methods <- function(client) {
  list(
    close = function() invisible(NULL),
    request_async = function(method, path, params = list(), json = NULL, headers = NULL) {
      phenoworks_request_async(client, path, method, params, json, headers)
    },
    request_parallel = function(requests, max_active = 4L) {
      phenoworks_request_parallel(client, requests, max_active)
    },
    request = function(method, path, params = list(), json = NULL, headers = NULL) {
      phenoworks_request(client, path, method, params, json, headers)
    },
    get = function(path, params = list(), headers = NULL) {
      phenoworks_request(client, path, query = params, headers = headers)
    },
    post = function(path, json = NULL, headers = NULL) {
      phenoworks_request(client, path, "POST", body = json, headers = headers)
    },
    download = function(path, destination, overwrite = FALSE, headers = NULL, progress = NULL, ...) {
      phenoworks_download(client, path, destination, overwrite, list(...), headers, progress)
    },
    download_artifact = function(artifact_id, destination, overwrite = FALSE, headers = NULL, progress = NULL) {
      phenoworks_download_artifact(client, artifact_id, destination, overwrite, headers, progress)
    },
    stream = function(method, path, params = list(), headers = NULL) {
      phenoworks_stream(client, method, path, params, headers)
    },
    save_stream = phenoworks_save_stream,
    upload_file = function(path, file, data = list(), headers = NULL) {
      phenoworks_upload_file(client, path, file, data, headers)
    },
    upload_project_file = function(project_id, path, data_product = "other", description = NULL,
                                   progress = NULL, headers = NULL) {
      phenoworks_upload_project_file(client, project_id, path, data_product, description, progress, headers)
    },
    upload_study_file = function(study_id, path, data_product = "other", description = NULL,
                                 progress = NULL, headers = NULL) {
      phenoworks_upload_study_file(client, study_id, path, data_product, description, progress, headers)
    },
    transfer_upload = function(registration, path, upload_url = NULL, chunk_size = 8 * 1024 * 1024,
                               progress = NULL, session_created = NULL, headers = NULL) {
      phenoworks_transfer_upload(client, registration, path, upload_url, chunk_size, progress, session_created, headers)
    },
    filter_datasets_by_modality = function(modality, project_id = NULL, study_id = NULL, headers = NULL) {
      phenoworks_filter_datasets_by_modality(client, modality, project_id, study_id, headers)
    },
    run_pipeline = function(dataset_id, json_pipeline, pipeline_name = NULL,
                            parameters = stats::setNames(list(), character()), modalities = NULL, headers = NULL) {
      phenoworks_run_pipeline(client, dataset_id, json_pipeline, pipeline_name, parameters, modalities, headers)
    },
    pipeline_run = function(pipeline_id, operation_id = NULL, headers = NULL) {
      phenoworks_pipeline_run(client, pipeline_id, operation_id, headers)
    }
  )
}
