#' Upload a multipart file
#' @inheritParams phenoworks_request
#' @param file Local filename to stream as the multipart field named file.
#' @param data Named list of additional form fields; NULL entries are omitted.
#' @return Decoded server response. Writes are never automatically retried.
#' @export
phenoworks_upload_file <- function(client, path, file, data = list(), headers = NULL) {
  file <- local_file(file)
  if (!is.list(data) || (length(data) && (is.null(names(data)) || any(!nzchar(names(data)))))) {
    stop("data must be a named list.")
  }
  if ("file" %in% names(data)) stop("data must not contain the file field.")
  data <- lapply(data[!vapply(data, is.null, logical(1))], as.character)
  req <- api_request(client, path, "POST", headers = headers)
  req <- do.call(httr2::req_body_multipart,
                 c(list(req, file = curl::form_file(file)), data))
  decode_response(httr2::req_perform(req), credential_secrets(request_auth(client, headers)))
}

#' Upload a file to a project or study
#' @inheritParams phenoworks_request
#' @param project_id Numeric or character project identifier.
#' @param study_id Numeric or character study identifier.
#' @param path Local file to register, transfer and finalize.
#' @param data_product Character data-product classification; defaults to other.
#' @param description Optional character description.
#' @param progress Optional function receiving committed bytes and total bytes.
#' @return Finalized file and processing-operation response. To resume across R
#'   sessions, register through client$uploads and use phenoworks_transfer_upload().
#' @name upload_scope_file
NULL

#' @rdname upload_scope_file
#' @export
phenoworks_upload_project_file <- function(client, project_id, path, data_product = "other",
                                          description = NULL, progress = NULL, headers = NULL) {
  upload_scope_file(client, "project", project_id, path, data_product, description, progress, headers)
}

#' @rdname upload_scope_file
#' @export
phenoworks_upload_study_file <- function(client, study_id, path, data_product = "other",
                                        description = NULL, progress = NULL, headers = NULL) {
  upload_scope_file(client, "study", study_id, path, data_product, description, progress, headers)
}

#' Register and transfer one scoped file
#' @inheritParams upload_scope_file
#' @param scope Character project or study.
#' @param id Scope identifier.
#' @return Finalized upload response.
#' @keywords internal
upload_scope_file <- function(client, scope, id, path, data_product, description, progress, headers) {
  path <- local_file(path)
  check_callback(progress, "progress")
  payload <- list(filename = basename(path), size_bytes = file.info(path)$size,
                  content_type = unname(mime::guess_type(path, empty = "application/octet-stream")),
                  data_product = data_product, description = description)
  payload[[paste0(scope, "_id")]] <- id
  registration <- phenoworks_request(client, paste0("uploads/", scope, "-files"),
                                     "POST", body = payload, headers = headers)
  phenoworks_transfer_upload(client, registration, path, progress = progress, headers = headers)
}

#' Resume or transfer a registered upload
#' @inheritParams phenoworks_request
#' @inheritParams upload_scope_file
#' @param registration Saved response from client$uploads$register_project() or
#'   register_study(). Contains file and upload instructions.
#' @param upload_url Optional saved transfer-session URL for resuming.
#' @param chunk_size Positive integer bytes per chunk, at most the R integer
#'   limit; for GCS must be a multiple of 256 KiB. Defaults to 8 MiB.
#' @param session_created Optional function receiving the session URL before
#'   transfer. Persist this URL securely together with registration for recovery.
#' @return Finalized file and operation response. Failures retain remote state
#'   for explicit resumption; no request is retried or re-registered automatically.
#'   Transfer hosts receive only server-provided headers, never client credentials.
#' @export
phenoworks_transfer_upload <- function(client, registration, path, upload_url = NULL,
                                       chunk_size = 8 * 1024 * 1024, progress = NULL,
                                       session_created = NULL, headers = NULL) {
  path <- local_file(path)
  request_auth(client, headers) # Fail before a transfer if finalization cannot authenticate.
  check_callback(progress, "progress")
  check_callback(session_created, "session_created")
  if (!is.numeric(chunk_size) || length(chunk_size) != 1L || is.na(chunk_size) ||
      !is.finite(chunk_size) || chunk_size <= 0 || chunk_size != floor(chunk_size) ||
      chunk_size > .Machine$integer.max) stop("chunk_size must be a positive integer within R's limit.")
  size <- file.info(path)$size
  record <- registration$file
  instructions <- registration$upload
  metadata <- record$metadata_json
  if (is.null(record$id) || is.null(record$project_id)) stop("registration must contain file identifiers.")
  if (!is.null(metadata$size_bytes) && size != metadata$size_bytes) {
    stop("File size differs from the registered upload.")
  }
  backend <- instructions$backend
  if (is.null(backend) || !backend %in% c("tusd", "gcs")) stop("Unsupported upload backend.")
  if (backend == "gcs" && chunk_size %% (256 * 1024) != 0) {
    stop("GCS chunk_size must be a multiple of 256 KiB.")
  }
  scope <- if (is.null(record$study_id)) "project-file" else "study-file"
  endpoint <- transfer_url(instructions$upload_url, client$base_url)
  transfer_headers <- instructions$headers
  if (is.null(transfer_headers)) transfer_headers <- list()
  transfer_headers <- as.list(transfer_headers)
  # Redact permits, signed URLs and client credentials from transfer diagnostics.
  secrets <- c(credential_secrets(request_auth(client, headers)),
               unlist(transfer_headers, use.names = FALSE), metadata$upload_permit, endpoint)
  if (backend == "tusd") {
    transfer_headers[["Tus-Resumable"]] <- "1.0.0"
    if (is.null(upload_url)) {
      values <- list(uploadPermit = if (is.null(metadata$upload_permit)) "" else metadata$upload_permit,
                     filename = basename(path), projectId = record$project_id, scope = scope,
                     studyId = if (is.null(record$study_id)) "" else record$study_id)
      values[[if (scope == "study-file") "studyFileId" else "projectFileId"]] <- record$id
      encoded <- vapply(values, function(value) openssl::base64_encode(charToRaw(as.character(value))),
                         character(1))
      creation_headers <- c(transfer_headers, list(`Upload-Length` = format(size, scientific = FALSE, trim = TRUE),
                            `Upload-Metadata` = paste(names(encoded), encoded, collapse = ",")))
      resp <- transfer_request(client, "POST", endpoint, creation_headers)
      check_response(resp, secrets)
      upload_url <- transfer_url(httr2::resp_header(resp, "Location"), endpoint)
    } else {
      upload_url <- transfer_url(upload_url, endpoint)
    }
  } else {
    upload_url <- if (is.null(upload_url)) endpoint else transfer_url(upload_url, endpoint)
  }
  secrets <- c(secrets, upload_url)
  if (!is.null(session_created)) session_created(upload_url)
  if (backend == "tusd") {
    resp <- transfer_request(client, "HEAD", upload_url, transfer_headers)
    check_response(resp, secrets)
    offset <- upload_offset(httr2::resp_header(resp, "Upload-Offset"))
  } else {
    resp <- transfer_request(client, "PUT", upload_url,
                              c(transfer_headers, list(`Content-Range` = paste0("bytes */", format(size, scientific = FALSE, trim = TRUE)))), raw())
    if (httr2::resp_status(resp) == 308L) {
      if (size == 0) stop("GCS has not finalized this empty upload.")
      offset <- gcs_offset(resp)
    } else {
      check_response(resp, secrets)
      offset <- size
    }
  }
  if (offset < 0 || offset > size) stop("Upload server returned an invalid offset.")
  source <- file(path, "rb")
  on.exit(close(source))
  seek(source, offset)
  while (offset < size) {
    chunk <- readBin(source, raw(), n = min(chunk_size, size - offset))
    if (!length(chunk)) stop("Local file changed during upload.")
    end <- offset + length(chunk)
    if (backend == "tusd") {
      resp <- transfer_request(client, "PATCH", upload_url,
                                c(transfer_headers, list(`Upload-Offset` = format(offset, scientific = FALSE, trim = TRUE),
                                  `Content-Type` = "application/offset+octet-stream")), chunk)
      check_response(resp, secrets)
      committed <- upload_offset(httr2::resp_header(resp, "Upload-Offset"))
    } else {
      resp <- transfer_request(client, "PUT", upload_url,
                                c(transfer_headers, list(`Content-Range` =
                                  paste0("bytes ", format(offset, scientific = FALSE, trim = TRUE), "-",
                                         format(end - 1, scientific = FALSE, trim = TRUE), "/",
                                         format(size, scientific = FALSE, trim = TRUE)))), chunk)
      if (httr2::resp_status(resp) == 308L) {
        committed <- gcs_offset(resp)
        if (end == size) stop("GCS did not finalize the upload; resume the saved session.")
      } else {
        check_response(resp, secrets)
        committed <- size
      }
    }
    if (committed != end) stop("Upload offset mismatch; resume the saved session.")
    offset <- committed
    if (!is.null(progress)) progress(offset, size)
  }
  phenoworks_request(client, "uploads/complete", "POST", headers = headers,
                      body = list(scope = scope, file_id = record$id, project_id = record$project_id,
                                  study_id = record$study_id, upload_url = upload_url))
}

#' Validate a readable local file
#' @param path Character filename.
#' @return Expanded filename; missing files and directories raise an error.
#' @keywords internal
local_file <- function(path) {
  check_string(path, "path")
  path <- path.expand(path)
  if (!file.exists(path) || isTRUE(file.info(path)$isdir) || file.access(path, 4L) != 0) {
    stop("Not a readable local file: ", path)
  }
  path
}

#' Resolve an upload URL without API-root restrictions
#' @param value Character absolute or relative URL.
#' @param base Character base URL for resolution.
#' @return HTTP(S) URL without embedded credentials or fragments.
#' @keywords internal
transfer_url <- function(value, base) {
  check_string(value, "upload_url")
  url <- httr2::url_parse(value, base_url = base)
  if (!url$scheme %in% c("http", "https") || is.null(url$hostname) ||
      !is.null(url$username) || !is.null(url$password) || !is.null(url$fragment)) {
    stop("Upload sessions must use HTTP(S) without embedded credentials or fragments.")
  }
  httr2::url_build(url)
}

#' Perform an isolated transfer request
#' @param client Client providing only its request timeout.
#' @param method HTTP verb.
#' @param url Validated upload-session URL.
#' @param headers Server-provided transfer headers; never the client auth list.
#' @param body Raw chunk or NULL for no body.
#' @return httr2 response, including GCS 308 acknowledgements. Network errors propagate.
#' @keywords internal
transfer_request <- function(client, method, url, headers, body = NULL) {
  req <- httr2::request(url) |>
    httr2::req_timeout(client$timeout) |>
    httr2::req_options(followlocation = FALSE) |>
    httr2::req_error(is_error = function(resp) FALSE)
  req <- do.call(httr2::req_headers_redacted, c(list(req), headers))
  if (!is.null(body)) req <- httr2::req_body_raw(req, body)
  httr2::req_perform(httr2::req_method(req, method))
}

#' Parse a resumable-upload offset
#' @param value Character offset header.
#' @return Nonnegative integer-valued number; malformed headers raise an error.
#' @keywords internal
upload_offset <- function(value) {
  if (is.null(value) || length(value) != 1L || !grepl("^[0-9]+$", value)) {
    stop("Upload server returned an invalid offset.")
  }
  offset <- as.numeric(value)
  if (!is.finite(offset)) stop("Upload server returned an invalid offset.")
  offset
}

#' Read a GCS committed byte range
#' @param resp GCS resumable-upload response.
#' @return Next byte offset, or zero when no bytes are committed.
#' @keywords internal
gcs_offset <- function(resp) {
  value <- httr2::resp_header(resp, "Range")
  if (is.null(value)) return(0)
  if (!grepl("^bytes=0-[0-9]+$", value)) stop("GCS returned an invalid range.")
  upload_offset(sub("^bytes=0-", "", value)) + 1
}
