#' Read common PhenoWorks resources
#'
#' These small helpers use [phenoworks_request()]. Query names and response
#' shapes follow the server API; no automatic pagination or data-frame coercion
#' is performed. Use phenoworks_request() for other endpoints and writes.
#'
#' @param client A client created by [phenoworks_client()].
#' @param query Named list of endpoint query parameters.
#' @return Decoded JSON as R lists and scalars. API and network errors propagate
#'   from phenoworks_request().
#' @name resources
NULL

#' @rdname resources
#' @export
phenoworks_me <- function(client) {
  phenoworks_request(client, "auth/me")
}

#' @rdname resources
#' @export
phenoworks_projects <- function(client, query = list()) {
  phenoworks_request(client, "projects", query = query)
}

#' @rdname resources
#' @export
phenoworks_datasets <- function(client, query = list()) {
  phenoworks_request(client, "datasets", query = query)
}

#' @rdname resources
#' @export
phenoworks_pipelines <- function(client, query = list()) {
  phenoworks_request(client, "pipelines", query = query)
}
