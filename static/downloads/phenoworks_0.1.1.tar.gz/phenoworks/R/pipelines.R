#' Submit a pipeline once
#' @inheritParams phenoworks_request
#' @param dataset_id Dataset identifier.
#' @param json_pipeline LgoPy definition as a serialized JSON string, named list
#'   (object), or unnamed list of blocks (array).
#' @param pipeline_name Optional character display name.
#' @param parameters Named list of dataset configuration values.
#' @param modalities Optional character vector of input modalities.
#' @return A phenoworks_pipeline_run handle with separate pipeline_id and
#'   operation_id fields and status(), cancel(), artifacts(), and wait() methods.
#' @export
phenoworks_run_pipeline <- function(client, dataset_id, json_pipeline, pipeline_name = NULL,
                                    parameters = stats::setNames(list(), character()),
                                    modalities = NULL, headers = NULL) {
  operation <- phenoworks_request(client, "pipelines", "POST", headers = headers,
                                  body = list(dataset_id = dataset_id, json_pipeline = json_pipeline,
                                              pipeline_name = pipeline_name, parameters = parameters,
                                              modalities = if (is.null(modalities)) NULL else as.list(modalities)))
  if (is.null(operation$id) || is.null(operation$payload$pipeline_id)) {
    stop("Submission response did not include operation and pipeline IDs; check server state before resubmitting.")
  }
  phenoworks_pipeline_run(client, operation$payload$pipeline_id, operation$id, headers)
}

#' Reconnect to an existing pipeline
#' @inheritParams phenoworks_request
#' @param pipeline_id Existing pipeline identifier.
#' @param operation_id Optional operation identifier for detecting queue failures.
#' @return A run handle without submitting work or making a network request.
#' @export
phenoworks_pipeline_run <- function(client, pipeline_id, operation_id = NULL, headers = NULL) {
  request_auth(client, headers)
  path_component(pipeline_id)
  if (!is.null(operation_id)) path_component(operation_id)
  run <- structure(list(client = client, pipeline_id = pipeline_id,
                         operation_id = operation_id, headers = headers), class = "phenoworks_pipeline_run")
  methods <- list(
    status = function() phenoworks_request(client, paste0("pipelines/", path_component(pipeline_id)), headers = headers),
    cancel = function() phenoworks_request(client, paste0("pipelines/", path_component(pipeline_id), "/cancel"),
                                           "POST", headers = headers),
    artifacts = function() phenoworks_request(client, "artifacts", query = list(pipeline_id = pipeline_id), headers = headers),
    wait = function(timeout = 3600, poll_interval = 2, progress = NULL) {
      phenoworks_wait_pipeline(run, timeout, poll_interval, progress)
    }
  )
  structure(c(run, methods), class = "phenoworks_pipeline_run")
}

#' Wait for a pipeline to finish
#' @param run Handle returned by phenoworks_run_pipeline() or phenoworks_pipeline_run().
#' @param timeout Nonnegative number of seconds to wait. Each in-flight request
#'   is separately bounded by the client's timeout.
#' @param poll_interval Positive seconds between status checks.
#' @param progress Optional function receiving each pipeline status record.
#' @return Completed pipeline record. Raises phenoworks_pipeline_failed_error
#'   (with pipeline_id and record) on pipeline or operation failure/cancellation,
#'   or phenoworks_pipeline_timeout_error (with pipeline_id) when waiting expires.
#'   A timeout never cancels or resubmits remote work.
#' @export
phenoworks_wait_pipeline <- function(run, timeout = 3600, poll_interval = 2, progress = NULL) {
  if (!inherits(run, "phenoworks_pipeline_run")) stop("run must be a pipeline handle.")
  if (!is.numeric(timeout) || length(timeout) != 1L || is.na(timeout) ||
      !is.finite(timeout) || timeout < 0) stop("timeout must be nonnegative and finite.")
  if (!is.numeric(poll_interval) || length(poll_interval) != 1L || is.na(poll_interval) ||
      !is.finite(poll_interval) || poll_interval <= 0) stop("poll_interval must be positive and finite.")
  check_callback(progress, "progress")
  deadline <- proc.time()[["elapsed"]] + timeout
  repeat {
    record <- phenoworks_request(run$client, paste0("pipelines/", path_component(run$pipeline_id)), headers = run$headers)
    if (!is.null(progress)) progress(record)
    check_pipeline_record(run$pipeline_id, record)
    if (identical(record$status, "completed")) return(record)
    if (!is.null(run$operation_id)) {
      operation <- phenoworks_request(run$client, paste0("operations/", path_component(run$operation_id)), headers = run$headers)
      check_pipeline_record(run$pipeline_id, operation)
    }
    remaining <- deadline - proc.time()[["elapsed"]]
    if (remaining <= 0) {
      stop(structure(list(message = paste0("Timed out waiting for pipeline ", run$pipeline_id,
                                          "; the run was not cancelled."), call = NULL,
                          pipeline_id = run$pipeline_id),
                     class = c("phenoworks_pipeline_timeout_error", "phenoworks_error", "error", "condition")))
    }
    Sys.sleep(min(poll_interval, remaining))
  }
}

#' Check a pipeline or associated operation for failure
#' @param pipeline_id Run identifier to retain in errors.
#' @param record Decoded pipeline or operation record.
#' @return NULL invisibly; failures raise a condition retaining the record.
#' @keywords internal
check_pipeline_record <- function(pipeline_id, record) {
  if (is.null(record$status)) stop("Server record is missing status.")
  if (record$status %in% c("failed", "cancelled")) {
    stop(structure(list(message = paste("Pipeline", pipeline_id, record$status,
                                        if (is.null(record$error_message)) "See record for details" else record$error_message),
                        call = NULL, pipeline_id = pipeline_id, record = record),
                   class = c("phenoworks_pipeline_failed_error", "phenoworks_error", "error", "condition")))
  }
  invisible(NULL)
}

#' Print a pipeline handle without credentials
#' @param x A phenoworks_pipeline_run object.
#' @param ... Unused additional arguments.
#' @return The run handle invisibly.
#' @export
print.phenoworks_pipeline_run <- function(x, ...) {
  cat("<phenoworks_pipeline_run>\n  Pipeline: ", x$pipeline_id,
      "\n  Operation: ", if (is.null(x$operation_id)) "unknown" else x$operation_id, "\n", sep = "")
  invisible(x)
}

#' Find datasets declaring support for a modality
#' @inheritParams phenoworks_request
#' @param modality Non-empty character modality, normalized for whitespace and case.
#' @param project_id Optional project identifier.
#' @param study_id Optional study identifier.
#' @return List of matching datasets in server order. Checks declared support,
#'   not whether matching assets have been uploaded.
#' @export
phenoworks_filter_datasets_by_modality <- function(client, modality, project_id = NULL,
                                                  study_id = NULL, headers = NULL) {
  check_string(modality, "modality")
  modality <- tolower(trimws(modality))
  datasets <- phenoworks_request(client, "datasets", query = list(project_id = project_id, study_id = study_id),
                                 headers = headers)
  Filter(function(dataset) modality %in% tolower(unlist(dataset$supported_modalities)), datasets)
}
