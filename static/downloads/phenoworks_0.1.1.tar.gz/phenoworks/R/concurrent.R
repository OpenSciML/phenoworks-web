#' Perform JSON requests concurrently
#' @param client Configured phenoworks_client.
#' @param requests List of named argument lists for phenoworks_request(), omitting
#'   client. Each contains path and optionally method, query, body, and headers.
#' @param max_active Positive integer maximum simultaneous requests.
#' @return List of decoded responses in input order, preserving request names.
#'   Any failure raises an error; other requests may already have completed.
#'   Requests are not retried. Use for independent operations only.
#' @export
phenoworks_request_parallel <- function(client, requests, max_active = 4L) {
  if (!is.list(requests)) stop("requests must be a list of request argument lists.")
  if (!is.numeric(max_active) || length(max_active) != 1L || is.na(max_active) ||
      !is.finite(max_active) || max_active < 1 || max_active != floor(max_active)) {
    stop("max_active must be a positive integer.")
  }
  if (!length(requests)) return(list())
  reqs <- lapply(requests, function(args) {
    do.call(api_request, c(list(client = client), args)) |>
      httr2::req_throttle(capacity = max_active, fill_time_s = 1, realm = client$base_url)
  })
  responses <- httr2::req_perform_parallel(reqs, max_active = max_active, progress = FALSE)
  result <- lapply(seq_along(responses), function(i) {
    decode_response(responses[[i]], credential_secrets(request_auth(client, requests[[i]]$headers)))
  })
  names(result) <- names(requests)
  result
}

#' Perform a JSON request asynchronously
#' @inheritParams phenoworks_request
#' @return A promises promise resolving to decoded JSON or rejecting with the
#'   same errors as phenoworks_request(). Requires the optional promises and later
#'   packages. Suitable for Shiny or an R event loop; does not block while waiting.
#' @export
phenoworks_request_async <- function(client, path, method = "GET", query = list(),
                                     body = NULL, headers = NULL) {
  if (!requireNamespace("promises", quietly = TRUE) || !requireNamespace("later", quietly = TRUE)) {
    stop("Install promises and later to use asynchronous requests.")
  }
  req <- api_request(client, path, method, query, body, headers)
  secrets <- credential_secrets(request_auth(client, headers))
  promises::then(httr2::req_perform_promise(req), function(resp) decode_response(resp, secrets))
}
