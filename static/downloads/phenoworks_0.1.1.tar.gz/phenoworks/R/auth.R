#' Validate request credentials
#' @param headers Named list or character vector of HTTP headers.
#' @return One canonical credential header. Invalid credentials raise an error.
#' @keywords internal
credential_headers <- function(headers) {
  if (is.null(names(headers)) || anyDuplicated(tolower(names(headers)))) {
    stop("headers must have unique, case-insensitive names.", call. = FALSE)
  }
  headers <- as.list(headers)
  names(headers) <- tolower(names(headers))
  key <- headers[["x-api-key"]]
  token <- headers[["authorization"]]
  if (is.null(key) == is.null(token)) {
    stop("Pass exactly one credential: X-API-Key or Authorization: Bearer <token>.",
         call. = FALSE)
  }
  value <- if (is.null(key)) token else key
  check_string(value, if (is.null(key)) "Authorization" else "api_key")
  if (grepl("[\r\n]", value)) stop("api_key or token must not contain line breaks.")
  if (!is.null(key)) return(list(`X-API-Key` = trimws(key)))
  if (!grepl("^Bearer +[^ ]", trimws(token), ignore.case = TRUE)) {
    stop("Authorization must contain a bearer token.", call. = FALSE)
  }
  list(Authorization = paste("Bearer", trimws(sub("^[^ ]+ +", "", trimws(token)))))
}

#' Resolve credentials without mutating a shared client
#' @param client Configured client.
#' @param headers Optional replacement credential headers.
#' @return Canonical credential headers; missing credentials raise an error.
#' @keywords internal
request_auth <- function(client, headers = NULL) {
  if (!inherits(client, "phenoworks_client")) stop("client must be created by phenoworks_client().")
  if (!is.null(headers)) return(credential_headers(headers))
  if (client$forward_auth_headers) stop("This client requires credentials on every request.")
  client$auth_headers
}

#' Extract secrets for redaction
#' @param headers Canonical credential headers.
#' @return Character vector of secrets without the bearer scheme.
#' @keywords internal
credential_secrets <- function(headers) {
  sub("^Bearer +", "", unlist(headers, use.names = FALSE))
}
