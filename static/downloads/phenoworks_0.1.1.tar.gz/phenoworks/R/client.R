#' Connect to the PhenoWorks API
#'
#' Creates a client without making a network request. Authentication uses the
#' same X-API-Key header and environment variables as the Python SDK.
#'
#' @param api_key Non-empty character API key. Defaults to PHENOWORKS_API_KEY.
#' @param base_url HTTP(S) server URL or API root. Reverse-proxy prefixes are
#'   preserved. Defaults to PHENOWORKS_API_URL, then http://localhost:9000.
#' @param timeout Positive number of seconds allowed for each request.
#' @param auth_token Optional bearer token, mutually exclusive with api_key.
#' @param forward_auth_headers Logical; require credentials on every request,
#'   ignoring environment credentials. Mutually exclusive with fixed credentials.
#' @return A phenoworks_client object. Invalid configuration raises an error.
#' @export
#' @examples
#' client <- phenoworks_client("example-key", "https://phenoworks.example")
#' client
phenoworks_client <- function(
    api_key = NULL,
    base_url = Sys.getenv("PHENOWORKS_API_URL", "http://localhost:9000"),
    timeout = 30, auth_token = NULL, forward_auth_headers = FALSE) {
  check_string(base_url, "base_url")
  if (!is.logical(forward_auth_headers) || length(forward_auth_headers) != 1L ||
      is.na(forward_auth_headers)) stop("forward_auth_headers must be TRUE or FALSE.")
  if (sum(!is.null(api_key), !is.null(auth_token), forward_auth_headers) > 1L) {
    stop("Pass only one credential mode: api_key, auth_token, or forward_auth_headers.")
  }
  auth <- list()
  if (!forward_auth_headers) {
    if (!is.null(auth_token)) {
      check_string(auth_token, "auth_token")
      auth <- credential_headers(list(Authorization = paste("Bearer", auth_token)))
    } else {
      if (is.null(api_key)) api_key <- Sys.getenv("PHENOWORKS_API_KEY")
      check_string(api_key, "api_key")
      auth <- credential_headers(list(`X-API-Key` = api_key))
    }
  }
  if (!is.numeric(timeout) || length(timeout) != 1L ||
      is.na(timeout) || !is.finite(timeout) || timeout <= 0) {
    stop("timeout must be a positive number of seconds.", call. = FALSE)
  }
  url <- httr2::url_parse(trimws(base_url))
  if (!url$scheme %in% c("http", "https") ||
      is.null(url$hostname) || !nzchar(url$hostname) ||
      !is.null(url$username) || !is.null(url$password) ||
      length(url$query) > 0L || !is.null(url$fragment)) {
    stop("base_url must be an HTTP(S) URL without credentials, query, or fragment.",
         call. = FALSE)
  }
  path <- sub("/+$", "", url$path)
  if (!endsWith(path, "/api")) path <- paste0(path, "/api")
  url$path <- paste0(path, "/")
  client <- structure(list(base_url = httr2::url_build(url), api_key = api_key,
                           timeout = timeout, auth_headers = auth,
                           forward_auth_headers = forward_auth_headers),
                      class = "phenoworks_client")
  # Methods capture this immutable configuration, not another copy of themselves.
  c(client, bind_resources(client), bind_client_methods(client)) |>
    structure(class = "phenoworks_client")
}

#' Print a client without displaying its API key
#' @param x A phenoworks_client object.
#' @param ... Unused additional arguments.
#' @return The client, invisibly.
#' @export
print.phenoworks_client <- function(x, ...) {
  cat("<phenoworks_client>\n", "  API: ", x$base_url, "\n", sep = "")
  invisible(x)
}

#' Validate a required string
#' @param value Value to check; must be one non-blank character string.
#' @param name Character argument name used in the error message.
#' @return NULL invisibly; invalid values raise an error.
#' @keywords internal
check_string <- function(value, name) {
  if (!is.character(value) || length(value) != 1L || is.na(value) ||
      !nzchar(trimws(value))) {
    stop(name, " must be a non-empty string.", call. = FALSE)
  }
  invisible(NULL)
}
