#' Open an authenticated response stream
#' @inheritParams phenoworks_request
#' @return An httr2 response with an open binary connection in body. The caller
#'   must close it with close(response$body), including on error. HTTP failures
#'   close the connection before raising a typed error.
#' @export
phenoworks_stream <- function(client, method, path, query = list(), headers = NULL) {
  req <- api_request(client, path, method, query, headers = headers) |>
    httr2::req_headers(`Accept-Encoding` = "identity")
  resp <- httr2::req_perform_connection(req)
  if (httr2::resp_status(resp) < 200L || httr2::resp_status(resp) >= 300L) {
    connection <- resp$body
    on.exit(close(connection))
    resp$body <- readBin(connection, raw(), n = 65536L)
    check_response(resp, credential_secrets(request_auth(client, headers)))
  }
  resp
}

#' Save a response stream atomically
#' @param response Successful response returned by phenoworks_stream(). The
#'   caller retains ownership of its connection and must close it after saving.
#' @param destination Character output filename. Parent directories are created.
#' @param overwrite Logical; replace an existing file only after success.
#' @param progress Optional function receiving downloaded bytes and total bytes
#'   (NULL when unknown). Called initially and after each chunk.
#' @return List with path, size_bytes and sha256. Failed transfers remove their
#'   temporary files and preserve existing destination files.
#' @export
phenoworks_save_stream <- function(response, destination, overwrite = FALSE,
                                  progress = NULL) {
  check_string(destination, "destination")
  check_flag(overwrite, "overwrite")
  check_callback(progress, "progress")
  check_response(response)
  destination <- path.expand(destination)
  if (file.exists(destination) && !overwrite) stop("Destination already exists: ", destination)
  dir.create(dirname(destination), recursive = TRUE, showWarnings = FALSE)
  temporary <- tempfile(".phenoworks-", tmpdir = dirname(destination), fileext = ".part")
  output <- NULL
  on.exit({
    if (!is.null(output)) close(output)
    unlink(temporary)
  }, add = TRUE)
  output <- file(temporary, "wb")
  source <- response$body
  if (is.raw(source)) {
    source <- rawConnection(source)
    on.exit(close(source), add = TRUE)
  }
  total <- httr2::resp_header(response, "Content-Length")
  if (!is.null(total)) total <- as.numeric(total)
  count <- 0
  if (!is.null(progress)) progress(count, total)
  repeat {
    chunk <- readBin(source, raw(), n = 1024L * 1024L)
    if (!length(chunk)) break
    writeBin(chunk, output)
    count <- count + length(chunk)
    if (!is.null(progress)) progress(count, total)
  }
  if (!is.null(total) && is.null(httr2::resp_header(response, "Content-Encoding")) &&
      (!is.finite(total) || count != total)) stop("Incomplete download: Content-Length mismatch.")
  close(output)
  output <- NULL
  hash_connection <- file(temporary, "rb")
  digest <- tryCatch(paste0(openssl::sha256(hash_connection)),
                     finally = close(hash_connection))
  published <- if (overwrite) file.rename(temporary, destination) else file.link(temporary, destination)
  if (!published) stop("Could not publish download: ", destination)
  list(path = destination, size_bytes = count, sha256 = digest)
}

#' Download API content to a local file
#' @inheritParams phenoworks_request
#' @inheritParams phenoworks_save_stream
#' @return Destination filename. HTTP and transport errors leave existing files
#'   untouched. Content is streamed with bounded memory.
#' @export
phenoworks_download <- function(client, path, destination, overwrite = FALSE,
                               query = list(), headers = NULL, progress = NULL) {
  check_string(destination, "destination")
  check_flag(overwrite, "overwrite")
  check_callback(progress, "progress")
  if (file.exists(path.expand(destination)) && !overwrite) stop("Destination already exists: ", destination)
  response <- phenoworks_stream(client, "GET", path, query, headers)
  on.exit(close(response$body))
  phenoworks_save_stream(response, destination, overwrite, progress)$path
}

#' Download a pipeline artifact
#' @inheritParams phenoworks_download
#' @param artifact_id Numeric or character artifact identifier.
#' @return Destination filename, suitable for read.csv(), terra::rast(), etc.
#' @export
phenoworks_download_artifact <- function(client, artifact_id, destination,
                                        overwrite = FALSE, headers = NULL, progress = NULL) {
  phenoworks_download(client, paste0("artifacts/", path_component(artifact_id), "/content"),
                      destination, overwrite, headers = headers, progress = progress)
}

#' Validate a logical flag
#' @param value Value to validate.
#' @param name Character argument name for diagnostics.
#' @return NULL invisibly; invalid values raise an error.
#' @keywords internal
check_flag <- function(value, name) {
  if (!is.logical(value) || length(value) != 1L || is.na(value)) stop(name, " must be TRUE or FALSE.")
  invisible(NULL)
}

#' Validate an optional callback
#' @param value Function or NULL.
#' @param name Character argument name for diagnostics.
#' @return NULL invisibly; invalid values raise an error.
#' @keywords internal
check_callback <- function(value, name) {
  if (!is.null(value) && !is.function(value)) stop(name, " must be a function or NULL.")
  invisible(NULL)
}
